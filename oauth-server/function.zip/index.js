// Servidor OAuth para Decap CMS con GitHub
// Compatible con AWS Lambda

const crypto = require('crypto');

// Configuración desde variables de entorno
const config = {
  clientId: process.env.GITHUB_CLIENT_ID,
  clientSecret: process.env.GITHUB_CLIENT_SECRET,
  redirectUrl: process.env.REDIRECT_URL || 'https://blog.tangara.studio/admin/',
};

// Genera estado aleatorio para prevenir CSRF
function randomState() {
  return crypto.randomBytes(16).toString('hex');
}

// Handler principal de Lambda
exports.handler = async (event) => {
  console.log('Full event:', JSON.stringify(event, null, 2));
  
  // HTTP API v2 (payload format 2.0) estructura
  const httpMethod = event.requestContext?.http?.method || 'GET';
  const path = event.requestContext?.http?.path || event.rawPath || '/';
  const queryStringParameters = event.queryStringParameters || {};
  
  console.log('Parsed:', { httpMethod, path, queryStringParameters });

  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  // Handle OPTIONS (preflight)
  if (httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  // Ruta: /auth - Inicia el flujo OAuth
  if (path.endsWith('/auth') && httpMethod === 'GET') {
    const state = randomState();
    const authUrl = 
      `https://github.com/login/oauth/authorize?` +
      `client_id=${config.clientId}&` +
      `scope=repo,user&` +
      `state=${state}`;

    return {
      statusCode: 302,
      headers: {
        ...headers,
        Location: authUrl,
      },
      body: '',
    };
  }

  // Ruta: /callback - GitHub redirige aquí con el código
  if (path.endsWith('/callback') && httpMethod === 'GET') {
    const { code, state } = queryStringParameters;

    if (!code) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Missing authorization code' }),
      };
    }

    try {
      // Intercambiar código por token de acceso
      const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          client_id: config.clientId,
          client_secret: config.clientSecret,
          code,
        }),
      });

      const tokenData = await tokenResponse.json();

      if (tokenData.error) {
        throw new Error(tokenData.error_description || tokenData.error);
      }

      // Página HTML con postMessage para Decap CMS
      // Implementa el protocolo de handshake que Decap CMS espera
      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>Autenticación exitosa</title>
        </head>
        <body>
          <h2>✓ Autenticación exitosa</h2>
          <p id="status">Comunicándose con el CMS...</p>
          <button onclick="window.close()">Cerrar ventana</button>
          <div id="debug" style="margin-top: 20px; padding: 10px; background: #f5f5f5; font-family: monospace; font-size: 11px;"></div>
          
          <script>
            (function() {
              var debugEl = document.getElementById('debug');
              var statusEl = document.getElementById('status');
              
              function log(msg) {
                console.log(msg);
                debugEl.innerHTML += msg + '<br>';
              }
              
              log('=== Decap CMS OAuth Callback ===');
              log('Window opener exists: ' + !!window.opener);
              
              if (!window.opener) {
                log('ERROR: No window.opener found!');
                statusEl.textContent = 'Error: No se pudo comunicar con la ventana principal.';
                return;
              }
              
              var token = "${tokenData.access_token}";
              var provider = "github";
              var content = { token: token, provider: provider };
              var messageSent = false;
              
              log('Token length: ' + token.length);
              log('Token start: ' + token.substring(0, 10) + '...');
              
              // Función para enviar el token
              function sendToken(targetOrigin) {
                if (messageSent) return;
                messageSent = true;
                
                var message = "authorization:" + provider + ":success:" + JSON.stringify(content);
                
                log('📤 Sending token...');
                log('   To origin: ' + targetOrigin);
                log('   Message length: ' + message.length);
                
                try {
                  // Enviar formato con prefijo (vencax/netlify-cms-github-oauth-provider)
                  window.opener.postMessage(message, targetOrigin);
                  log('✅ Token sent (format 1: prefixed string)');
                  
                  // TAMBIÉN enviar solo el objeto (algunos OAuth servers usan este formato)
                  window.opener.postMessage(content, targetOrigin);
                  log('✅ Token sent (format 2: object only)');
                  
                  statusEl.textContent = '✓ Autenticación completada. Puedes cerrar esta ventana.';
                  
                  // Cerrar después de 2 segundos
                  setTimeout(function() {
                    log('Closing window...');
                    window.close();
                  }, 2000);
                } catch (err) {
                  log('❌ Error sending: ' + err.message);
                  // Si falla con el origen específico, intentar con wildcard
                  if (targetOrigin !== '*') {
                    log('   Retrying with wildcard...');
                    messageSent = false;
                    sendToken('*');
                  } else {
                    statusEl.textContent = 'Error: ' + err.message;
                  }
                }
              }
              
              // Listener para mensajes del CMS
              function receiveMessage(e) {
                log('📨 Received message from: ' + (e.origin || 'null'));
                log('   Data: ' + e.data);
                
                // Cuando recibimos CUALQUIER mensaje del opener, enviamos el token
                var targetOrigin = e.origin || '*';
                sendToken(targetOrigin);
              }
              
              // Escuchar mensajes
              window.addEventListener("message", receiveMessage, false);
              
              // Iniciar handshake
              log('🚀 Initiating handshake...');
              log('   Sending: authorizing:' + provider);
              
              try {
                window.opener.postMessage("authorizing:" + provider, "*");
                log('✅ Handshake sent!');
                statusEl.textContent = 'Esperando respuesta del CMS...';
              } catch (err) {
                log('❌ Error in handshake: ' + err.message);
                statusEl.textContent = 'Error: ' + err.message;
              }
              
              // Si no recibimos respuesta en 1 segundo, enviar el token de todas formas
              setTimeout(function() {
                if (!messageSent) {
                  log('⏰ No response from CMS, sending token anyway with wildcard...');
                  sendToken('*');
                }
              }, 1000);
              
              // Timeout de seguridad (15 segundos)
              setTimeout(function() {
                if (!messageSent) {
                  log('⏰ Timeout - No response from CMS');
                  statusEl.textContent = 'Timeout: No se recibió respuesta del CMS. Puedes cerrar esta ventana.';
                }
              }, 15000);
            })();
          </script>
        </body>
        </html>
      `;

      return {
        statusCode: 200,
        headers: {
          ...headers,
          'Content-Type': 'text/html',
        },
        body: html,
      };
    } catch (error) {
      console.error('OAuth error:', error);
      
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'Authentication failed', 
          details: error.message 
        }),
      };
    }
  }

  // Ruta: /success - Confirmación visual (opcional)
  if (path.endsWith('/success') && httpMethod === 'GET') {
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Autenticación exitosa</title>
        <style>
          body {
            font-family: system-ui, -apple-system, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: #f5f5f5;
          }
          .container {
            text-align: center;
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          }
          h1 { color: #2e7d32; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>✓ Autenticación exitosa</h1>
          <p>Puedes cerrar esta ventana y volver al CMS.</p>
        </div>
      </body>
      </html>
    `;

    return {
      statusCode: 200,
      headers: {
        ...headers,
        'Content-Type': 'text/html',
      },
      body: html,
    };
  }

  // Ruta no encontrada
  return {
    statusCode: 404,
    headers,
    body: JSON.stringify({ error: 'Not found' }),
  };
};
